#!/bin/bash
output_dir=/Users/htran/Documents/storage_tmp/metastasis_trees/downloading_scripts/
input="/Users/htran/Documents/storage_tmp/metastasis_trees/downloading_scripts/jira_tickets.txt"
results_blob_prefix="https://singlecellresults.blob.core.windows.net/results/"
results_blob_suffix_hmm="/results/hmmcopy/reads.csv.gz"
results_blob_suffix_anno="/results/annotation/metrics.csv.gz"


while IFS= read -r line
do
  if [ -z "$line" ]
  then
        # echo "\$line is empty"
        echo ""
  else
        echo $line
        jira_ticket=${line%,*}
        library_id=${line#*,}
        echo $jira_ticket
        echo $library_id
        mkdir "${output_dir}${library_id}"
        
        echo "\nDownloading hmmcopy data"
        output_hmmcopy_fd="${output_dir}${library_id}/hmmcopy/"
        mkdir $output_hmmcopy_fd
        command_script1="~/az storage copy -s ${results_blob_prefix}${jira_ticket}${results_blob_suffix_hmm} -d ${output_hmmcopy_fd}"
        echo $command_script1
        eval "$command_script1"
        
        echo "\nDownloading hmmcopy annotation data"
        output_hmmcopy_anno="${output_dir}${library_id}/annotation/"
        mkdir $output_hmmcopy_anno
        command_script2="~/az storage copy -s ${results_blob_prefix}${jira_ticket}${results_blob_suffix_anno} -d $output_hmmcopy_anno"
        echo $command_script2
        eval "$command_script2"

  fi

done < "$input"




