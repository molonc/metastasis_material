## Defines generic accessors
setGeneric("drivers", function(x) standardGeneric("drivers"))

setGeneric("actualEvents", function(x) standardGeneric("actualEvents"))

setGeneric("totalEvents", function(x) standardGeneric("totalEvents"))
