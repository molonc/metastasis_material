Six FI files in this zipped file:

FIs in UniProt accession numbers:
FIs_043009.txt (FIs from both pathways and NBC predicted)
FIs_Pathway_043009.txt (FIs extracted from Pathways)
FIs_Predicted_043009.txt (FIs predicted by NBC trained by FIs extracted from Reactome FIs)

FIs in gene names extracted from UniProt database:
FIsInGene_043009.txt (FIs from both pathways and NBC predicted)
FIsInGene_Pathway_043009.txt (FIs extracted from Pathways)
FIsInGene_Predicted_043009.txt (FIs predicted by NBC trained by FIs extracted from Reactome FIs)

