de_out.csv.gz: all genes that are taken into account: significant and non significant. 
DE_signif_genes.csv.gz: significant genes with thresholds:   logFC_thrs <- 0.5
  p_val_thrs <- 0.05
